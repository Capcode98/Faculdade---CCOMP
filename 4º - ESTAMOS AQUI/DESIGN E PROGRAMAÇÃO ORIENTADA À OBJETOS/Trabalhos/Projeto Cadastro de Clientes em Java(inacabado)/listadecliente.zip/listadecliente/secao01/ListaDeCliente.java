package br.com.listadecliente.secao01;
import java.util.ArrayList;
import java.util.Scanner;
public class ListaDeCliente {
    private Scanner teclado = new Scanner(System.in);
    ArrayList<Cliente> lista;
    public ListaDeCliente(){
        lista = new ArrayList<>();
    }
    void cadastrar(Cliente cliente){
        Cliente cliente;
        cliente = new Cliente("marcos", "21-12356789","marcos@gmail.com","rua","03",
                "proximo da loja","pessegueiro", "Teresopolis", "Rj","259009001");
        lista.add(cliente);
    }
    void alterar(Cliente cliente){
        int opc;
        System.out.println("Qual informação deseja alterar?" +
                "1 - Nome" +
                "2 - Telefone" +
                "3 - E-mail" +
                "4 - Logradouro" +
                "5 - Numero" +
                "6 - complemento" +
                "7 - Bairro" +
                "8 - cidade" +
                "9 - estado" +
                "10 - cep") ;
        opc =  Integer.parseInt(teclado.nextLine());
        switch (opc){
            case 1:
                System.out.println("Insira o novo nome: ");
                cliente.alterarNome(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 2:
                System.out.println("Insira o novo telefone: ");
                cliente.alterarTelefone(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 3:
                System.out.println("Insira o novo E-mail: ");
                cliente.alterarEmail(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 4:
                System.out.println("Insira o novo Logradouro: ");
                cliente.alterarLogradouro(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 5:
                System.out.println("Insira o novo numero: ");
                cliente.alterarNumero(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 6:
                System.out.println("Insira o novo complemento: ");
                cliente.alterarComplemento(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 7:
                System.out.println("Insira o novo bairrp: ");
                cliente.alterarBairro(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 8:
                System.out.println("Insira o novo cidade: ");
                cliente.alterarCidade(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 9:
                System.out.println("Insira o novo estado: ");
                cliente.alterarEstado(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            case 10:
                System.out.println("Insira o novo cep: ");
                cliente.alterarCep(teclado.nextLine());
                System.out.println("Alterado com sucesso.");
                break;
            default:
                System.out.println("Opção inválida. Tente outra. ");
                System.out.println("Alterado com sucesso.");
                break;
        }

    }
}
