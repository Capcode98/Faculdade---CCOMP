package br.com.listadecliente.secao01;

public class Cliente {
    private String nome, telefone, email, logradouro, numero, complemento, bairro, cidade, estado, cep;
    public Cliente(String nome, String telefone, String email,
                   String logradouro, String numero, String complemento,
                   String bairro, String cidade, String estado,
                   String cep){

        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
        this.logradouro = logradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.cep = cep;
        }
        //getters
        String obterNome(){
            return nome;
        }
        String obterTelefone(){
            return telefone;
        }
        String obterEmail(){
            return email;
        }
        String obterLogradouro(){
            return logradouro;
        }
        String obterNumero(){
            return numero;
        }
        String obtercomplemento(){
            return complemento;
        }
        String obterBairro(){
            return bairro;
        }
        String obterCidade(){
            return cidade;
        }
        String obterEstado(){
            return estado;
        }
        String obterCep(){
            return cep;
        }
        //Setters - alteração dos atributos
        void alterarNome(String nome){
            this.nome = nome;
        }

        void alterarTelefone(String telefone){
            this.telefone = telefone;
        }

        void alterarEmail(String email){
            this.email = email;
        }
        void alterarLogradouro(String logradouro){
            this.logradouro = logradouro;
        }
        void alterarNumero(String numero){
            this.numero = numero;
        }
        void alterarComplemento(String complemento){
            this.complemento = complemento;
        }
        void alterarBairro(String bairro){
            this.bairro = bairro;
        }
        void alterarCidade(String cidade){
            this.cidade = cidade;
        }
        void alterarEstado(String estado){
            this.estado = estado;
        }
        void alterarCep(String cep){
            this.cep = cep;
        }
    }

