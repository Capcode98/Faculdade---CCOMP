package br.com.listadecliente.secao01;

public class Programa {
    public static void main(String[] args) {
        ListaDeCliente gereciar = new ListaDeCliente();

    }


}
